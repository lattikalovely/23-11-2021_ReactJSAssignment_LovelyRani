import React, { Component } from 'react';
import '../App.css';
import Header from './Header.js';
import Car from './Car'
import { initialCars } from '../cars';
import { additionalCars } from '../cars';

class App extends Component {
  constructor() {
    super();
    this.state = {
      cars: initialCars
    };
    this.loadAdditionalCars = this.loadAdditionalCars.bind(this);
  }

  loadAdditionalCars() {
    var currentCars = { ...this.state.cars };
    var newCars = Object.assign(currentCars, additionalCars);
    this.setState({ cars: newCars });
  }

  render() {
    return (
      <div className="App">
        <Header text="Car Catalog" />
        <p className="App-intro">
          Some information about popular cars
        </p>
        <div className="cars">
          {
            Object
              .keys(this.state.cars)
              .map(key => <Car key={key} meta={this.state.cars[key]} />)
          }
        </div>
        <div className="add-cars"><button onClick={this.loadAdditionalCars}>See more...</button></div>
       

      </div>
    );
  }
}

export default App;
